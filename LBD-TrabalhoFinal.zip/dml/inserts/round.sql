INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(1, 1, 46, 36);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(2, 2, 27, 111);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(3, 3, 54, 121);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(4, 4, 20, 57);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(5, 5, 148, 105);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(6, 6, 42, 101);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(7, 7, 72, 67);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(8, 8, 89, 137);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(9, 9, 118, 7);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(10, 10, 21, 83);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(11, 11, 64, 16);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(12, 12, 86, 12);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(13, 13, 140, 97);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(14, 14, 84, 46);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(15, 15, 145, 78);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(16, 16, 102, 73);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(17, 17, 79, 113);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(18, 18, 37, 42);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(19, 19, 9, 94);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(20, 20, 55, 59);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(21, 21, 11, 110);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(22, 22, 54, 149);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(23, 23, 24, 43);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(24, 24, 106, 141);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(25, 25, 129, 84);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(26, 26, 25, 53);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(27, 27, 134, 142);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(28, 28, 113, 89);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(29, 29, 111, 62);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(30, 30, 47, 70);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(31, 31, 145, 111);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(32, 32, 37, 15);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(33, 33, 38, 2);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(34, 34, 45, 75);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(35, 35, 65, 86);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(36, 36, 22, 19);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(37, 37, 73, 2);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(38, 38, 75, 117);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(39, 39, 104, 86);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(40, 40, 70, 78);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(41, 41, 129, 115);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(42, 42, 79, 28);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(43, 43, 25, 12);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(44, 44, 57, 67);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(45, 45, 42, 26);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(46, 46, 70, 76);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(47, 47, 141, 69);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(48, 48, 60, 119);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(49, 49, 8, 136);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(50, 50, 68, 101);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(51, 51, 35, 71);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(52, 52, 37, 69);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(53, 53, 34, 17);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(54, 54, 124, 12);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(55, 55, 66, 38);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(56, 56, 22, 104);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(57, 57, 129, 59);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(58, 58, 112, 27);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(59, 59, 64, 83);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(60, 60, 132, 9);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(61, 61, 17, 68);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(62, 62, 109, 147);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(63, 63, 46, 121);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(64, 64, 60, 84);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(65, 65, 62, 108);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(66, 66, 143, 73);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(67, 67, 29, 1);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(68, 68, 109, 7);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(69, 69, 136, 129);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(70, 70, 61, 84);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(71, 71, 146, 126);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(72, 72, 28, 27);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(73, 73, 135, 105);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(74, 74, 72, 35);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(75, 75, 134, 74);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(76, 76, 73, 96);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(77, 77, 3, 35);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(78, 78, 139, 80);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(79, 79, 57, 7);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(80, 80, 143, 7);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(81, 81, 88, 22);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(82, 82, 78, 4);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(83, 83, 117, 62);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(84, 84, 106, 13);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(85, 85, 121, 88);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(86, 86, 110, 132);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(87, 87, 16, 51);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(88, 88, 59, 101);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(89, 89, 116, 81);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(90, 90, 90, 65);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(91, 91, 130, 71);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(92, 92, 104, 77);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(93, 93, 117, 44);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(94, 94, 147, 107);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(95, 95, 2, 79);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(96, 96, 28, 20);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(97, 97, 30, 130);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(98, 98, 111, 44);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(99, 99, 70, 31);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(100, 100, 64, 79);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(101, 101, 81, 146);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(102, 102, 1, 27);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(103, 103, 81, 84);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(104, 104, 85, 40);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(105, 105, 89, 126);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(106, 106, 130, 19);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(107, 107, 142, 105);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(108, 108, 42, 62);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(109, 109, 16, 27);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(110, 110, 36, 17);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(111, 111, 86, 70);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(112, 112, 54, 115);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(113, 113, 15, 14);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(114, 114, 32, 12);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(115, 115, 110, 61);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(116, 116, 112, 27);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(117, 117, 105, 148);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(118, 118, 84, 41);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(119, 119, 100, 39);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(120, 120, 143, 95);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(121, 121, 17, 82);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(122, 122, 32, 3);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(123, 123, 39, 24);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(124, 124, 111, 77);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(125, 125, 54, 61);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(126, 126, 26, 115);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(127, 127, 7, 71);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(128, 128, 73, 131);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(129, 129, 85, 54);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(130, 130, 120, 113);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(131, 131, 108, 51);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(132, 132, 66, 15);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(133, 133, 83, 135);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(134, 134, 39, 39);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(135, 135, 37, 44);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(136, 136, 90, 44);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(137, 137, 83, 94);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(138, 138, 114, 149);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(139, 139, 127, 42);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(140, 140, 48, 107);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(141, 141, 51, 146);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(142, 142, 107, 134);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(143, 143, 106, 83);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(144, 144, 89, 37);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(145, 145, 84, 30);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(146, 146, 77, 59);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(147, 147, 129, 143);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(148, 148, 4, 63);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(149, 149, 111, 15);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(150, 150, 140, 17);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(151, 151, 50, 64);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(152, 152, 107, 62);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(153, 153, 27, 39);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(154, 154, 12, 88);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(155, 155, 85, 140);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(156, 156, 31, 137);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(157, 157, 81, 5);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(158, 158, 34, 64);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(159, 159, 37, 62);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(160, 160, 137, 58);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(161, 161, 86, 131);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(162, 162, 112, 134);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(163, 163, 100, 21);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(164, 164, 44, 98);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(165, 165, 115, 82);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(166, 166, 118, 93);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(167, 167, 89, 82);
INSERT INTO round
(id, fk_batalha_id, fk_instancia_pokemon_id_1, fk_instancia_pokemon_id_2)
VALUES(168, 168, 55, 114);
