INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(1, false, false, 89, 87, 452, 591, 163);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(2, true, false, 93, 9, 433, 547, 45);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(3, false, true, 7, 9, 370, 409, 81);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(4, false, true, 16, 58, 92, 120, 6);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(5, false, false, 23, 58, 346, 389, 32);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(6, false, true, 55, 83, 385, 313, 57);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(7, false, true, 59, 75, 157, 94, 144);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(8, true, false, 36, 87, 466, 64, 153);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(9, false, true, 8, 16, 435, 206, 71);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(10, true, false, 75, 7, 201, 118, 147);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(11, false, true, 87, 75, 156, 430, 20);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(12, true, true, 5, 64, 26, 224, 137);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(13, true, false, 18, 31, 93, 150, 147);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(14, false, true, 72, 8, 419, 597, 79);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(15, true, NULL, 31, 16, 466, 2, 87);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(16, false, false, 11, 54, 122, 380, 116);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(17, true, true, 39, 20, 462, 250, 49);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(18, true, false, 70, 92, 340, 1, 4);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(19, true, false, 83, 94, 358, 575, 108);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(20, false, false, 71, 59, 119, 305, 61);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(21, false, false, 13, 19, 341, 316, 66);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(22, false, true, 56, 16, 567, 594, 99);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(23, true, true, 3, 93, 553, 582, 155);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(24, false, true, 24, 65, 209, 249, 138);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(25, true, false, 20, 32, 293, 84, 49);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(26, false, false, 6, 57, 574, 356, 92);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(27, false, false, 25, 97, 13, 215, 31);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(28, true, false, 99, 45, 509, 427, 103);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(29, true, true, 67, 33, 289, 134, 80);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(30, false, true, 58, 20, 467, 87, 12);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(31, false, true, 84, 84, 279, 168, 58);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(32, false, false, 93, 4, 346, 438, 13);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(33, false, true, 9, 78, 198, 445, 158);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(34, true, true, 71, 43, 293, 180, 133);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(35, false, false, 87, 69, 160, 140, 19);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(36, true, false, 62, 99, 43, 384, 56);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(37, false, true, 100, 50, 506, 488, 6);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(38, false, false, 99, 92, 109, 317, 5);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(39, true, false, 37, 36, 20, 310, 22);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(40, true, false, 64, 69, 428, 465, 46);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(41, false, false, 16, 12, 542, 357, 55);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(42, true, false, 23, 66, 359, 173, 29);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(43, true, true, 46, 95, 521, 23, 103);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(44, true, true, 51, 4, 452, 213, 166);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(45, false, true, 28, 79, 421, 148, 33);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(46, false, true, 96, 4, 249, 49, 88);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(47, false, false, 32, 72, 23, 409, 50);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(48, true, false, 23, 9, 165, 374, 4);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(49, false, true, 51, 57, 269, 121, 133);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(50, false, false, 100, 52, 119, 210, 43);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(51, true, false, 53, 61, 214, 135, 22);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(52, false, false, 45, 66, 195, 70, 66);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(53, false, true, 100, 6, 450, 28, 140);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(54, false, true, 93, 59, 542, 302, 134);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(55, true, true, 99, 58, 187, 238, 6);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(56, false, true, 100, 70, 153, 247, 78);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(57, true, true, 100, 28, 545, 403, 154);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(58, true, false, 15, 5, 20, 90, 92);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(59, false, true, 11, 44, 100, 27, 24);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(60, true, true, 99, 94, 448, 26, 20);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(61, true, true, 47, 75, 307, 567, 39);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(62, false, true, 74, 47, 56, 156, 164);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(63, true, true, 38, 78, 271, 6, 52);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(64, false, false, 36, 8, 391, 521, 96);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(65, false, false, 43, 92, 370, 5, 11);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(66, false, true, 54, 55, 465, 562, 42);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(67, true, false, 4, 69, 487, 30, 35);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(68, true, true, 37, 45, 331, 173, 48);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(69, true, false, 22, 76, 227, 157, 50);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(70, false, false, 64, 25, 338, 147, 163);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(71, true, false, 12, 20, 20, 71, 119);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(72, false, false, 96, 5, 375, 15, 75);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(73, true, true, 48, 5, 321, 168, 67);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(74, false, true, 20, 61, 585, 99, 5);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(75, false, false, 30, 47, 33, 447, 136);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(76, true, true, 12, 97, 202, 121, 21);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(77, true, true, 39, 94, 525, 332, 120);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(78, false, false, 17, 46, 557, 153, 23);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(79, true, true, 72, 97, 559, 189, 111);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(80, false, false, 4, 3, 338, 562, 57);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(81, true, false, 56, 53, 445, 136, 113);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(82, false, false, 67, 33, 302, 173, 57);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(83, true, false, 11, 65, 112, 71, 15);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(84, false, true, 91, 96, 343, 537, 104);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(85, true, false, 28, 37, 309, 387, 70);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(86, true, true, 8, 53, 353, 282, 147);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(87, false, false, 25, 65, 574, 250, 94);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(88, false, true, 32, 31, 144, 312, 142);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(89, true, false, 99, 47, 429, 355, 21);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(90, false, true, 83, 69, 259, 17, 32);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(91, false, false, 69, 13, 348, 173, 135);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(92, false, false, 91, 23, 112, 162, 107);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(93, true, false, 23, 84, 77, 263, 32);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(94, true, false, 68, 90, 383, 392, 30);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(95, false, true, 68, 25, 312, 229, 152);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(96, false, false, 40, 42, 227, 592, 91);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(97, true, false, 20, 68, 128, 148, 34);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(98, true, false, 64, 67, 391, 311, 13);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(99, false, true, 64, 92, 3, 301, 72);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(100, true, false, 11, 23, 481, 53, 84);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(101, false, true, 62, 73, 360, 115, 9);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(102, false, true, 16, 63, 241, 370, 144);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(103, true, false, 46, 3, 588, 223, 133);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(104, true, true, 97, 61, 41, 497, 127);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(105, false, false, 66, 48, 18, 123, 17);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(106, true, true, 19, 47, 37, 379, 138);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(107, false, false, 41, 67, 196, 293, 60);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(108, false, true, 52, 10, 110, 321, 107);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(109, true, true, 8, 17, 151, 22, 3);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(110, false, true, 54, 62, 514, 11, 163);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(111, false, true, 14, 7, 395, 102, 168);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(112, true, true, 62, 90, 399, 585, 22);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(113, true, false, 48, 71, 18, 283, 3);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(114, false, true, 24, 4, 35, 133, 53);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(115, true, true, 78, 36, 345, 530, 81);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(116, false, true, 37, 72, 397, 5, 16);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(117, true, true, 30, 67, 272, 263, 114);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(118, false, false, 87, 87, 94, 573, 64);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(119, false, false, 66, 43, 466, 517, 90);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(120, false, true, 23, 55, 94, 299, 155);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(121, true, false, 50, 96, 220, 165, 37);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(122, true, true, 36, 23, 357, 418, 22);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(123, true, true, 92, 48, 42, 429, 63);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(124, false, false, 11, 63, 70, 484, 138);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(125, false, true, 95, 43, 193, 554, 34);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(126, false, true, 54, 30, 472, 213, 168);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(127, true, false, 3, 18, 99, 570, 107);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(128, true, true, 80, 91, 84, 362, 32);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(129, true, true, 90, 88, 448, 112, 47);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(130, false, false, 92, 84, 403, 443, 133);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(131, false, false, 14, 32, 425, 439, 68);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(132, false, false, 45, 88, 506, 51, 116);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(133, true, false, 6, 85, 272, 47, 150);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(134, false, false, 22, 80, 96, 346, 98);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(135, false, false, 79, 6, 566, 550, 89);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(136, false, true, 1, 5, 160, 365, 145);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(137, true, false, 21, 99, 106, 150, 153);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(138, false, true, 22, 73, 43, 152, 89);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(139, false, true, 3, 60, 442, 14, 56);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(140, false, true, 69, 57, 204, 461, 122);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(141, false, false, 43, 67, 456, 71, 26);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(142, true, false, 26, 2, 13, 27, 24);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(143, true, true, 90, 74, 41, 71, 11);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(144, false, true, 30, 36, 95, 318, 102);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(145, true, false, 50, 50, 125, 279, 88);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(146, false, true, 77, 67, 354, 295, 81);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(147, true, false, 26, 16, 230, 530, 50);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(148, true, false, 92, 96, 528, 524, 83);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(149, false, false, 90, 80, 162, 406, 57);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(150, false, false, 68, 97, 146, 55, 115);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(151, false, true, 85, 5, 69, 520, 119);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(152, false, false, 86, 75, 331, 100, 128);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(153, false, true, 49, 49, 249, 15, 134);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(154, true, false, 29, 15, 38, 142, 55);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(155, false, true, 38, 92, 401, 451, 69);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(156, false, true, 77, 15, 78, 60, 8);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(157, true, true, 78, 37, 179, 83, 34);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(158, false, true, 2, 72, 536, 318, 107);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(159, true, false, 15, 58, 111, 409, 102);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(160, false, false, 53, 79, 133, 594, 36);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(161, true, false, 100, 91, 267, 282, 146);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(162, false, false, 17, 100, 317, 554, 1);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(163, true, false, 16, 30, 305, 487, 131);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(164, false, true, 11, 32, 374, 462, 51);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(165, false, true, 47, 72, 295, 3, 52);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(166, true, true, 31, 72, 590, 147, 133);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(167, true, false, 48, 42, 132, 124, 144);
INSERT INTO turno
(id_turno, escudo_1_uso, escudo_2_uso, dano_causado_pokemon_1, dano_causado_pokemon_2, habilidade_pokemon_1, habilidade_pokemon_2, fk_round_id)
VALUES(168, true, false, 98, 88, 242, 62, 82);
