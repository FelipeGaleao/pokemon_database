INSERT INTO public.torneio(id, nome) VALUES 
(1, 'Torneio da UFMS'),
(2, 'Torneio da UNICAMP'),
(3, 'Torneio do Terrinha - Santo Amaro');