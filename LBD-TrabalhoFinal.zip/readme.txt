| João Pedro Santos Vareiro | 2021.1906.035-2 |
| Maycon Felipe da Silva Mota | 2021.1906.069-7 |
| Vítor Oliveira Resende Brandão | 2021.1906.027-1 |
